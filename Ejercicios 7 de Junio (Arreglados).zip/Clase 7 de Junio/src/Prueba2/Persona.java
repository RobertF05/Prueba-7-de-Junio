package Prueba2;

import java.util.Scanner;

public class Persona {
	
	public String nombre, cedula, opc;
	public int edad;
	public Persona(String nombre, String cedula,String opc, int edad) {
		this.nombre = nombre;
		this.cedula = cedula;
		this.opc = opc;
		this.edad = edad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getOpc() {
		return cedula;
	}
	public void setOpc(String opc) {
		this.opc = opc;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	
	public void pedirDatos() {
		Scanner tc = new Scanner(System.in);
		System.out.println("Ingrese el nombre de la Persona: ");
		nombre = tc.nextLine();
		System.out.println("Desea Ingresar su edad? ");
		opc = tc.nextLine();
		if(opc.equals("si")) {
			try {
				System.out.println("Ingrese su edad: ");
				edad = tc.nextInt();
				tc.nextLine();
			} catch (Exception e) {
				System.out.println("No meta letras en la edad por favor");
				System.exit(0);
			}
		}else if(opc.equals("no")) {
			
		}else {
			System.out.println("Datos no valido");
		}
		if(edad >= 16) {
			System.out.println("Ingrese su numero de cedula: ");
			cedula = tc.nextLine();
		}
	}
	
	public void mostrar() {
		System.out.println("Nombre: "+nombre);
		if(edad == 0) {
			System.out.println("No ha ingresado edad");
		}else {
			System.out.println("Edad: "+edad);
		}
		System.out.println("Cedula: "+cedula);
	}
	public void esMayorDeEdad() {
		if (edad >= 18) {
			System.out.println("Es mayor de Edad");
		}
	}

}
