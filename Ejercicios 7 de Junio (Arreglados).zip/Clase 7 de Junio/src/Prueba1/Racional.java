package Prueba1;

import java.util.Scanner;

public class Racional {
	/*Crea una clase Racional que permita trabajar con números racionales (fracciones).
	Incluye los siguientes métodos: constructores (por defecto y parametrizado), accedentes,
	leer(), suma, resta, multiplicación, división, comparaciones, copia() y print(). 
	*/
	public static int a, b = 1, c, d = 1, sum, res, mult, div, sum2, res2, mult2, div2;
	
	public void leer() {
		try {
			Scanner tc = new Scanner(System.in);
			System.out.println("Ingrese el Numerador 1: ");
			a = tc.nextInt();
			System.out.println("Ingrese el Denominador 1: ");
			b = tc.nextInt();
			while(b == 0) {
				System.out.println("El Denominador no puede ser 0");
				System.out.println("Ingrese el Denominador 1: ");
				b = tc.nextInt();
			}
			System.out.println("Ingrese el Numerador 2: ");
			c = tc.nextInt();
			System.out.println("Ingrese el Denominador 2: ");
			d = tc.nextInt();	
			while(d == 0) {
				System.out.println("El Denominador no puede ser 0");
				System.out.println("Ingrese el Denominador d: ");
				d = tc.nextInt();
			}
		} catch (Exception e) {
			System.out.println("Valor Invalido");
			System.exit(0);
		}
	}
	
	public static void suma() {
		if(b == d) {
			sum = a + c;
			sum2 = b;
		}else {
			sum = a * d + c * b;
			sum2 = b * d;
		}
		System.out.println("La suma es: "+sum+"/"+sum2);
	}
	public static void resta() {
		if(b == d) {
			res = a - c;
			res2 = b;
		}else {
			res = a * d - c * d;
			res2 = b * d;
		}
		System.out.println("La resta es: "+res+"/"+res2);
	}
	public static void multiplicacion() {
		mult = a * c;
		mult2 = b * d;
		System.out.println("La multiplicacion es: "+mult+"/"+mult2);
	}
	public static void division() {
		div = a * d;
		div2 = b * c;
		System.out.println("La division es: "+div+"/"+div2);
	}

}
