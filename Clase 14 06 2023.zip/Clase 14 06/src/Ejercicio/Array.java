package Ejercicio;

import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc = new Scanner(System.in);
		int n, array[] = new int[100], j = 0, auxSum = 0, aux, h = 0;
		double auxMed;
		
		System.out.println("Ingrese Datos");
		try {
			for (int i = 0; i < array.length; i++) {
				array[i] = tc.nextInt();
				if(array[i] == -99) {
					i -= 1;
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Valor Invalido");
		}
		for (int i = 0; i < array.length; i++) {
			if(array[i] == -99) {
				i -= 1;
				break;
			}else {
				j += 1;
				aux = array[i];
				auxSum += aux;
			}
		}
		auxMed = (double)auxSum/j;
		System.out.println("La Cantidad de Numeros Ingresados es: "+j);
		System.out.println("La Suma de todos es: "+auxSum);
		System.out.println("La media es: "+ auxMed);
		System.out.println("Los valores Ingresados son:");
		for (int i = 0; i < array.length; i++) {
			if(array[i] == -99) {
				i -= 1;
				break;
			}else {
				System.out.print(array[i]+" ");
			}
		}
		System.out.println(" ");
		System.out.println("Los Valores Mayores a la Media son:");
		for (int i = 0; i < array.length; i++) {
			if(array[i] == -99) {
				i -= 1;
				break;
			}else if(array[i] > auxMed) {
				System.out.print(array[i]+" ");
				h += 1;
			}
		}
		System.out.println(" ");
		System.out.println("La Cantidad de Numeros Mayores a la Media es: "+h);
	}
}
