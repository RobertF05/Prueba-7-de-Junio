package Prueba2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Persona op = new Persona(null, null, null, 0);
		op.pedirDatos();
		op.mostrar();
		op.esMayorDeEdad();

	}

}
