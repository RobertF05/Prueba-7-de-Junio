package Prueba1;

import java.util.Scanner;

public class Racional {
	/*Crea una clase Racional que permita trabajar con números racionales (fracciones).
	Incluye los siguientes métodos: constructores (por defecto y parametrizado), accedentes,
	leer(), suma, resta, multiplicación, división, comparaciones, copia() y print(). 
	*/
	public int a, b, c, d, sum, res, mult, div;
	
	
	
	public Racional(int a, int b, int c, int d, int sum, int res, int mult, int div) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.sum = sum;
		this.res = res;
		this.mult = mult;
		this.div = div;
	}

	public void leer() {
		Scanner tc = new Scanner(System.in);
		System.out.println("Ingrese la fraccion 1: ");
	}
	
	public void print() {
		
	}

}
